package com.example.miniprojectandroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import com.example.miniprojectandroid.databinding.ActivityMainBinding; //import binding class

public class MainActivity extends AppCompatActivity {

    //declare variable for binding class
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //diploma button
        binding.dipBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //go to diploma activity
                Intent diplomaIntent = new Intent(MainActivity.this, DiplomaActivity.class);
                startActivity(diplomaIntent);
            }
        });

        //foundation button
        binding.fndBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //go to foundation activity
                Intent foundationIntent = new Intent(MainActivity.this, FoundationActivity.class);
                startActivity(foundationIntent);
            }
        });

        //a level button
        binding.alevelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: Add your logic for the A-Level programme.
            }
        });
    }
}
